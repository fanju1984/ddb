// Package wsproxy implements a websocket proxy for grpc-gateway backed services
package wsproxy
