// +build appengine

package runewidth

// IsEastAsian return true if the current locale is CJK
func IsEastAsian() bool {
	return false
}
