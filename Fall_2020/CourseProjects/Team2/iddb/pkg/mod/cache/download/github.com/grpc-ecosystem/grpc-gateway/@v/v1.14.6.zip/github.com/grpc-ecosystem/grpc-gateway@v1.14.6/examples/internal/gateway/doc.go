// Package gateway is an example of grpc-gateway server
package gateway
